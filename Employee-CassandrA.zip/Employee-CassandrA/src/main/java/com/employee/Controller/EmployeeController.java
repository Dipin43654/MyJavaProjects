package com.employee.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.employee.Entity.Employee;
import com.employee.Services.EmployeeService;

@Controller
public class EmployeeController 
{
	private EmployeeService employeeService;
	@Autowired
	public void setEmployeeService(EmployeeService employeeService)
	{
		this.employeeService = employeeService;
	}
	
	 @RequestMapping("/")
	 public String redirToList()
	 {
		 return "redirect:/employee/list";
	 }
	 
	 @RequestMapping({"/employee/list", "/employee"})
	 public String listProducts(Model model)
	 {
		 model.addAttribute("employees", employeeService.listAll());
	 	return "employee/list";
	 }
	 
	 @RequestMapping("/employee/show/{id}")
	 public String getEmployee(@PathVariable int id, Model model)
	 {
		 model.addAttribute("employee", employeeService.getById(id));
	     return "employee/show";
	 }
	 
	 @RequestMapping("/employee/edit/{id}")
	 public String edit(@PathVariable int id, Model model)
	 {
		 Employee employee = employeeService.getById(id);
		 model.addAttribute("employeeform", employee);
		 return "employee/employeeform";
	 }
	 
	 @RequestMapping("/employee/new")
	    public String newEmployee(Model model){
	        model.addAttribute("employeeform", new Employee());
	        return "employee/employeeform";
	    }


	    @RequestMapping("/employee/delete/{id}")
	    public String delete(@PathVariable int id){
	        employeeService.delete(id);;
	        return "redirect:/employee/list";
	    }
}
