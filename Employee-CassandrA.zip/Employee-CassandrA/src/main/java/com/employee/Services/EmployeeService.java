package com.employee.Services;

import java.util.List;

import com.employee.Entity.Employee;

public interface EmployeeService 
{
	List<Employee> listAll();

	Employee getById(int id);

	Employee saveOrUpdate(Employee product);

    void delete(int id);
}
