package com.employee.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.Entity.Employee;
import com.employee.Repository.EmployeeRepository;


@Service
public class EmployeeServiceImpl implements EmployeeService 
{
	private EmployeeRepository employeeRepository;

    @Autowired
    public EmployeeServiceImpl(EmployeeRepository employeeRepository) 
    {
        this.employeeRepository = employeeRepository;
    }

	@Override
	public List<Employee> listAll() {
		List<Employee> employees = new ArrayList<>();
		employeeRepository.findAll().forEach(employees::add);
		return employees;
	}

	@Override
	public Employee getById(int id) 
	{
		return employeeRepository.findById(id).orElse(null);
	}

	@Override
	public Employee saveOrUpdate(Employee employee) 
	{
		employeeRepository.save(employee);
		return employee;
	}

	@Override
	public void delete(int id) 
	{
		employeeRepository.deleteById(id);
	}
}
