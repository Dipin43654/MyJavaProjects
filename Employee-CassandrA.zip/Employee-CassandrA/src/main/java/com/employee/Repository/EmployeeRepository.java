package com.employee.Repository;

import org.springframework.data.repository.CrudRepository;

import com.employee.Entity.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}
